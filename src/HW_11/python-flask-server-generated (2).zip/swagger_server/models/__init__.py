# coding: utf-8

# flake8: noqa
from __future__ import absolute_import
# import models into model package
from swagger_server.models.group import Group
from swagger_server.models.robot import Robot
from swagger_server.models.schedule import Schedule
from swagger_server.models.user import User
