# swagger_client.ScheduleApi

All URIs are relative to *https://localhost:9669*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_schedule**](ScheduleApi.md#add_schedule) | **POST** /Schedule | Добавить расписание
[**delete_schedule**](ScheduleApi.md#delete_schedule) | **DELETE** /Schedule/deleteById/{id} | Удаляет задание из расписания
[**get_schedule_by_id**](ScheduleApi.md#get_schedule_by_id) | **GET** /Schedule/findById/{scheduleId} | Найти задание по ID
[**update_schedule**](ScheduleApi.md#update_schedule) | **PUT** /Schedule | Обновить расписание

# **add_schedule**
> Schedule add_schedule(body)

Добавить расписание

Добавить расписание в базу

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ScheduleApi()
body = swagger_client.Schedule() # Schedule | Создать новое расписание в базе

try:
    # Добавить расписание
    api_response = api_instance.add_schedule(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleApi->add_schedule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Schedule**](Schedule.md)| Создать новое расписание в базе | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_schedule**
> delete_schedule(id, id=id)

Удаляет задание из расписания

Удаляет задание из расписания

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ScheduleApi()
id = 789 # int | ID робота
id = 'id_example' # str |  (optional)

try:
    # Удаляет задание из расписания
    api_instance.delete_schedule(id, id=id)
except ApiException as e:
    print("Exception when calling ScheduleApi->delete_schedule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID робота | 
 **id** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_schedule_by_id**
> Schedule get_schedule_by_id(schedule_id)

Найти задание по ID

Найти задание по ID

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ScheduleApi()
schedule_id = 789 # int | Идентификатор задания

try:
    # Найти задание по ID
    api_response = api_instance.get_schedule_by_id(schedule_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleApi->get_schedule_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **int**| Идентификатор задания | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_schedule**
> Schedule update_schedule(body)

Обновить расписание

Обновить расписание

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ScheduleApi()
body = swagger_client.Schedule() # Schedule | Обновить существующее расписание в базе

try:
    # Обновить расписание
    api_response = api_instance.update_schedule(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleApi->update_schedule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Schedule**](Schedule.md)| Обновить существующее расписание в базе | 

### Return type

[**Schedule**](Schedule.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

